# LinkSafer-ChromeAddOn
Simple AddOn to Save the currentyl active tab and insert text.


![](https://github.com/sera619/LinkSafer-ChromeAddOn/blob/main/LinkSafer_2.png)


# TODO:
- interaction w/ website (check)
- add Tab save button (check)
- Offline Template initieren. (check)
- Kontakt Button (check v1.5.2)
- Help/instruction button 
- styling fixes.  (check)
- multi lang support
- puplish on google webstore
- add save list to fav
- export list to .txt (check v1.4.2)

**Für Fragen oder Anregungen:**
- Kontakt: Seraphinus619@gmail.com

# Installation!
Das Add On befindet sich momentan in der Betaphase. Zum vorab testen könnt ihr euch hier manuell, mit bebildeter Anleitung,
das AddOn installieren. Folgt einfach den Bildern.


Verzeichnis Downloaden und entpacken.
![](https://user-images.githubusercontent.com/67480273/122171649-41341480-ce80-11eb-8086-15b1a567d489.png)

![](https://user-images.githubusercontent.com/67480273/122171691-4b561300-ce80-11eb-935d-c858aea38a97.png)


Im Anschluss Chrome Browser öffnen und oben rechts in das AddOn-Widget klicken.

![](https://user-images.githubusercontent.com/67480273/122172347-f5ce3600-ce80-11eb-8d0b-7ac68c121548.png)

In den Erweiterungen nun den Developer-Modus aktivieren:

![](https://user-images.githubusercontent.com/67480273/122172463-0da5ba00-ce81-11eb-90c9-986307c2f61c.png)

Nun auf den Button "Entpackte Erweiterung laden":

![](https://user-images.githubusercontent.com/67480273/122172582-2f9f3c80-ce81-11eb-8bd8-4ddc3177144c.png)

Hier wählt ihr den entpackten Ordner "LinkSafer-ChromeAddOn-master". 

![](https://user-images.githubusercontent.com/67480273/122173010-99b7e180-ce81-11eb-92a2-6aa631aa6c41.png)

Fertig! 
Viel Spaß.




